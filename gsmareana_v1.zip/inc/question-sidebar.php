<div class="col-lg-4  overflow-hidden order-2 order-md-1 p-2">
                        <main class="row gy-3">
                           

                        <section>
                            <h6 class="content-title oswald-font fs-20">Subjects</h6>

                              <main class="px-2">

                            <?php

                               foreach (["Mathematics","English Language","Sweet Sixteen","Insurance","Economics","Civic Education","Home Economics","Data Processing","Marketing","French"] as $key => $value) {

                                  echo  "<h5 class='lh-1 py-2 border-bottom border-light'><a href='view_news.php' class='fs-14 fw-bold'>&#187; {$value} </a></h5>";

                                }

                                ?>

                              </main>

                        </section>

                    

                        </main>
</div>